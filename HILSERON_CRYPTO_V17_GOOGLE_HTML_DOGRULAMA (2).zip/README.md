HİLSERON CRYPTO V13

Bu sürüm stabilite ve sade ana ekran için hazırlanmıştır.
- Ana ekranda bölüm başına 10 coin.
- Genel / Yükselen / Düşen / Yeni / Hacim / Tüm Coinler / Favoriler.
- Arama tüm indirilen USDT piyasasında çalışır.
- Coin kartına dokununca ayrıntı ekranı açılır.
- 1S, 1G, 7G, 1A, 1Y, 5Y grafik aralıkları.
- Grafikte parmakla hareket ederek tarih ve fiyat görülebilir.
- Canlı fiyat akışı için WebSocket; yedek olarak periyodik yenileme.
- API hatasında sayfa donmaz ve son başarılı veri korunur.
- Harici marka/reklam metni kullanılmaz.

Yayınlama: Bu klasörü statik site olarak yükle. Sunucu tarafı gerekmez.
