const API='https://api.binance.com/api/v3';
const FALLBACK='https://api1.binance.com/api/v3';
const S={all:[],info:new Map(),view:'home',q:'',fav:new Set(JSON.parse(localStorage.getItem('hc_fav_v13')||'[]')),range:'7G',busy:false,lastGood:0,ws:null,detailSymbol:null};
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const money=n=>{n=Number(n);if(!Number.isFinite(n))return '—';let d=n>=1000?2:n>=1?4:8;return '$'+n.toLocaleString('en-US',{maximumFractionDigits:d})};
const compact=n=>{n=Number(n);if(!Number.isFinite(n))return '—';if(n>=1e12)return '$'+(n/1e12).toFixed(2)+'T';if(n>=1e9)return '$'+(n/1e9).toFixed(2)+'B';if(n>=1e6)return '$'+(n/1e6).toFixed(2)+'M';if(n>=1e3)return '$'+(n/1e3).toFixed(1)+'K';return money(n)};
const logo=s=>`https://assets.coincap.io/assets/icons/${String(s).toLowerCase()}@2x.png`;
function toast(t){let x=$('#toast');x.textContent=t;x.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(()=>x.style.display='none',2600)}
async function get(path,ms=10000){let ctrl=new AbortController(),tm=setTimeout(()=>ctrl.abort(),ms);try{let r=await fetch(API+path,{cache:'no-store',signal:ctrl.signal});if(!r.ok)throw Error('HTTP '+r.status);return await r.json()}catch(e){let r=await fetch(FALLBACK+path,{cache:'no-store'});if(!r.ok)throw e;return r.json()}finally{clearTimeout(tm)}}
function normalizeTicker(x){let s=x.symbol||'';if(!s.endsWith('USDT')||s.includes('_'))return null;let base=s.slice(0,-4);if(/(UP|DOWN|BULL|BEAR|2L|2S|3L|3S|5L|5S)$/.test(base))return null;let p=+x.lastPrice;if(!(p>0))return null;let c={s:base,pair:s,price:p,ch:+x.priceChangePercent||0,vol:+x.quoteVolume||0,hi:+x.highPrice||0,lo:+x.lowPrice||0,count:+x.count||0};let inf=S.info.get(s);if(inf){c.name=inf.name||base;c.onboard=inf.onboardDate||0}else{c.name=base;c.onboard=0}return c}
async function load(){if(S.busy)return;S.busy=true;setStatus(t('updating'));try{let [ticks,info]=await Promise.all([get('/ticker/24hr'),get('/exchangeInfo')]);S.info.clear();for(const x of (info.symbols||[])){if(x.quoteAsset==='USDT'&&x.status==='TRADING')S.info.set(x.symbol,{name:x.baseAsset,onboardDate:x.onboardDate||0})}let arr=[];for(const x of ticks){let c=normalizeTicker(x);if(c)arr.push(c)}arr.sort((a,b)=>b.vol-a.vol);S.all=arr;S.lastGood=Date.now();setStatus(`${t('live')} • ${arr.length.toLocaleString('tr-TR')} ${t('coins')} • ${new Date().toLocaleTimeString('tr-TR')}`);render();startTickerStream()}catch(e){setStatus(S.all.length?`Son başarılı veri gösteriliyor • ${new Date(S.lastGood).toLocaleTimeString('tr-TR')}`:'Veri kaynağına ulaşılamadı. Yenile ile tekrar deneyebilirsin.');if(!S.all.length)showEmpty('Piyasa verisi şu anda alınamadı.');toast('Veri bağlantısı kurulamadı. Sayfa donmadı; tekrar deneyebilirsin.')}finally{S.busy=false}}
function setStatus(t){$('#status').textContent=t}
function startTickerStream(){if(S.ws)return;try{let ws=new WebSocket('wss://stream.binance.com:9443/ws/!ticker@arr');S.ws=ws;ws.onmessage=e=>{try{let data=JSON.parse(e.data);let map=new Map(S.all.map(x=>[x.pair,x]));for(const x of data){let c=map.get(x.s);if(c){c.price=+x.c||c.price;c.ch=+x.P||c.ch;c.vol=+x.q||c.vol;c.hi=+x.h||c.hi;c.lo=+x.l||c.lo}}updateVisiblePrices()}catch(_){}};ws.onerror=()=>{try{ws.close()}catch(_){}};ws.onclose=()=>{S.ws=null}}catch(_){}}
function updateVisiblePrices(){document.querySelectorAll('.coin[data-s]').forEach(el=>{let c=S.all.find(x=>x.s===el.dataset.s);if(!c)return;let p=el.querySelector('.price'),ch=el.querySelector('.change');if(p)p.textContent=money(c.price);if(ch){ch.textContent=(c.ch>=0?'▲ ':'▼ ')+Math.abs(c.ch).toFixed(2)+'%';ch.className='change '+(c.ch>=0?'up':'down')}});if(S.detailSymbol){let c=S.all.find(x=>x.s===S.detailSymbol);if(c){let p=$('.detail-price'),ch=$('.detail-change');if(p)p.textContent=money(c.price);if(ch){ch.textContent=(c.ch>=0?'▲ ':'▼ ')+Math.abs(c.ch).toFixed(2)+'% / 24s';ch.className='detail-change '+(c.ch>=0?'up':'down')}}}}
function card(c){return `<article class="coin" data-s="${c.s}"><div class="coin-head"><img class="logo" src="${logo(c.s)}" onerror="this.style.display='none'"><div><div class="coin-name">${esc(c.name||c.s)}</div><div class="coin-pair">${c.s}/USDT</div></div><button class="star ${S.fav.has(c.s)?'on':''}" data-f="${c.s}" aria-label="Favori">★</button></div><div class="price">${money(c.price)}</div><div class="change ${c.ch>=0?'up':'down'}">${c.ch>=0?'▲':'▼'} ${Math.abs(c.ch).toFixed(2)}%</div><div class="meta"><span>Hacim</span><span>${compact(c.vol)}</span></div></article>`}
function section(title,sub,a,n=10){return `<section class="section"><div class="section-head"><div><div class="section-title">${title}</div><div class="section-sub">${sub}</div></div></div><div class="grid">${a.slice(0,n).map(card).join('')||'<div class="empty">Sonuç bulunamadı.</div>'}</div></section>`}
function render(){let a=S.all;if(S.q){let q=S.q.toLowerCase();let f=a.filter(c=>(c.s+' '+c.name+' '+c.pair).toLowerCase().includes(q));$('#app').innerHTML=section(t('searchResults'),`${f.length} ${t('matches')}`,f,30);return}let g=[...a].sort((x,y)=>y.ch-x.ch),l=[...a].sort((x,y)=>x.ch-y.ch),v=[...a].sort((x,y)=>y.vol-x.vol),f=a.filter(x=>S.fav.has(x.s)),now=Date.now(),newc=[...a].filter(x=>x.onboard&&now-x.onboard<1000*60*60*24*30).sort((x,y)=>y.onboard-x.onboard);if(S.view==='gainers')return $('#app').innerHTML=section('🚀 '+t('gainers'),'24 '+t('hours'),g,30);if(S.view==='losers')return $('#app').innerHTML=section('📉 '+t('losers'),'24 '+t('hours'),l,30);if(S.view==='volume')return $('#app').innerHTML=section('🔥 '+t('volume'),'USDT '+t('market'),v,30);if(S.view==='new')return $('#app').innerHTML=section('🆕 '+t('new'),'30 '+t('days'),newc,30);if(S.view==='fav')return $('#app').innerHTML=section('⭐ '+t('favorites'),t('watchlist'),f,30);if(S.view==='all')return $('#app').innerHTML=table(a);$('#app').innerHTML=section(t('featured'),t('home10'),v,10)+section('🚀 '+t('gainers'),'24 '+t('home10'),g,10)+section('📉 '+t('losers'),'24 '+t('home10'),l,10)+section('🔥 '+t('volume'),'24 '+t('home10'),v,10)}
function table(a){return `<section class="section"><div class="section-title">Tüm Coinler</div><div class="section-sub">${a.length.toLocaleString('tr-TR')} aktif USDT paritesi • Arama ile hızlı bul</div><div class="table-wrap"><div class="row th"><span>#</span><span>Coin</span><span>Fiyat</span><span>24s</span><span>Hacim</span><span>24s Yüksek / Düşük</span></div>${a.slice(0,300).map((c,i)=>`<div class="row" data-s="${c.s}"><span>${i+1}</span><span class="coin-cell"><img class="tiny-logo" src="${logo(c.s)}" onerror="this.style.display='none'"><b>${esc(c.name||c.s)}</b><small>${c.s}</small></span><span>${money(c.price)}</span><span class="${c.ch>=0?'up':'down'}">${c.ch.toFixed(2)}%</span><span>${compact(c.vol)}</span><span>${money(c.hi)} / ${money(c.lo)}</span></div>`).join('')}</div></section>`}
function showEmpty(t){$('#app').innerHTML=`<div class="empty">${t}</div>`}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
async function openCoin(s){let c=S.all.find(x=>x.s===s);if(!c)return;S.detailSymbol=s;$('#modal').classList.remove('hidden');$('#modal').setAttribute('aria-hidden','false');$('#detail').innerHTML=`<div class="detail-head"><img class="detail-logo" src="${logo(s)}" onerror="this.style.display='none'"><div><div class="detail-title">${esc(c.name||s)}</div><div class="detail-pair">${s}/USDT • Canlı piyasa</div></div></div><div class="detail-price">${money(c.price)}</div><div class="detail-change ${c.ch>=0?'up':'down'}">${c.ch>=0?'▲':'▼'} ${Math.abs(c.ch).toFixed(2)}% / 24s</div><div class="chart-wrap"><div id="chartBox" class="chart-box"><div class="loading-chart">Grafik verisi yükleniyor…</div></div></div><div class="ranges">${['1S','1G','7G','1A','1Y','5Y'].map(r=>`<button class="range ${S.range===r?'active':''}" data-r="${r}">${r}</button>`).join('')}</div><div class="detail-grid"><div class="stat"><small>Market hacmi 24s</small><b>${compact(c.vol)}</b></div><div class="stat"><small>24s en yüksek</small><b>${money(c.hi)}</b></div><div class="stat"><small>24s en düşük</small><b>${money(c.lo)}</b></div><div class="stat"><small>İşlem sayısı</small><b>${c.count.toLocaleString('tr-TR')}</b></div></div><div class="source">Canlı fiyat: halka açık piyasa verisi • Grafik: seçilen zaman aralığı</div>`;await loadChart(s,S.range)}
function params(r){return r==='1S'?['1m',60]:r==='1G'?['5m',288]:r==='7G'?['1h',168]:r==='1A'?['4h',180]:r==='1Y'?['1d',365]:['1d',1000]}
async function klines(symbol,interval,limit,end){let q=`/klines?symbol=${symbol}USDT&interval=${interval}&limit=${limit}`+(end?`&endTime=${end}`:'');return get(q,12000)}
async function loadChart(s,r){let box=$('#chartBox');if(!box)return;box.innerHTML='<div class="loading-chart">Grafik verisi yükleniyor…</div>';try{let [i,l]=params(r),rows=[];if(r==='5Y'){let end=Date.now();for(let n=0;n<3;n++){let part=await klines(s,i,1000,end);if(!part.length)break;rows=part.concat(rows);end=part[0][0]-1;if(part.length<1000)break}}else rows=await klines(s,i,l);let p=rows.map(x=>({t:+x[0],v:+x[4]}));if(!p.length)throw Error('empty');box.innerHTML='<canvas id="cv"></canvas><div id="tip" class="tip"></div>';draw(p); }catch(e){box.innerHTML='<div class="loading-chart">Grafik verisi alınamadı. Diğer zaman aralığını deneyebilirsin.</div>'}}
function draw(p){let c=$('#cv'),box=$('#chartBox'),ctx=c.getContext('2d'),w=box.clientWidth,h=box.clientHeight,d=Math.min(devicePixelRatio||1,2);c.width=w*d;c.height=h*d;ctx.setTransform(d,0,0,d,0,0);let pa={l:78,r:18,t:18,b:28},cw=Math.max(1,w-pa.l-pa.r),ch=h-pa.t-pa.b,z=p.map(x=>x.v),mn=Math.min(...z),mx=Math.max(...z),sp=mx-mn||Math.max(1,mn*.01),lo=mn-sp*.08,hi=mx+sp*.08;const X=i=>pa.l+(p.length===1?0:i/(p.length-1))*cw,Y=q=>pa.t+(1-(q-lo)/(hi-lo))*ch;ctx.font='12px system-ui';ctx.fillStyle='#7d90aa';ctx.strokeStyle='#172942';ctx.lineWidth=1;for(let i=0;i<6;i++){let y=pa.t+i*ch/5;ctx.beginPath();ctx.moveTo(pa.l,y);ctx.lineTo(w-pa.r,y);ctx.stroke();ctx.fillText(money(hi-(hi-lo)*i/5),4,y+4)}ctx.beginPath();p.forEach((q,i)=>i?ctx.lineTo(X(i),Y(q.v)):ctx.moveTo(X(i),Y(q.v)));ctx.strokeStyle='#20d9da';ctx.lineWidth=2.5;ctx.stroke();let tip=$('#tip');const show=e=>{let r=c.getBoundingClientRect(),px=e.clientX-r.left,py=e.clientY-r.top,i=Math.max(0,Math.min(p.length-1,Math.round((px-pa.l)/cw*(p.length-1)))),q=p[i];tip.style.display='block';tip.style.left=Math.min(Math.max(px+8,5),w-190)+'px';tip.style.top=Math.min(Math.max(py-48,5),h-35)+'px';tip.textContent=new Date(q.t).toLocaleString('tr-TR',{day:'2-digit',month:'2-digit',year:'2-digit',hour:'2-digit',minute:'2-digit'})+' • '+money(q.v)};c.onpointermove=show;c.onpointerdown=show;c.onpointerleave=()=>tip.style.display='none';c.ontouchmove=show}

const LANGS={
tr:{name:"Türkçe",flag:"🇹🇷",code:"TR",live:"Canlı piyasa",coins:"coin",updating:"Piyasa verisi güncelleniyor…",gainers:"Yükselenler",losers:"Düşenler",volume:"En yüksek hacim",new:"Yeni listelenenler",favorites:"Favoriler",featured:"Öne çıkanlar",home10:"Ana ekran • 10 coin",hours:"saat",days:"gün",market:"piyasası",watchlist:"Kişisel izleme listen",searchResults:"Arama sonuçları",matches:"eşleşme"},
en:{name:"English",flag:"🇬🇧",code:"EN",live:"Live market",coins:"coins",updating:"Updating market data…",gainers:"Top Gainers",losers:"Top Losers",volume:"Highest Volume",new:"New Listings",favorites:"Favorites",featured:"Featured",home10:"Home • 10 coins",hours:"hours",days:"days",market:"market",watchlist:"Your watchlist",searchResults:"Search results",matches:"matches"},
es:{name:"Español",flag:"🇪🇸",code:"ES",live:"Mercado en vivo",coins:"monedas",updating:"Actualizando datos…",gainers:"Subidas",losers:"Bajadas",volume:"Mayor volumen",new:"Nuevas cotizaciones",favorites:"Favoritos",featured:"Destacados",home10:"Inicio • 10 monedas",hours:"horas",days:"días",market:"mercado",watchlist:"Tu lista",searchResults:"Resultados",matches:"coincidencias"},
zh:{name:"中文",flag:"🇨🇳",code:"ZH",live:"实时市场",coins:"币种",updating:"正在更新市场数据…",gainers:"涨幅榜",losers:"跌幅榜",volume:"最高成交量",new:"新上线",favorites:"收藏",featured:"热门",home10:"首页 • 10 个币种",hours:"小时",days:"天",market:"市场",watchlist:"我的自选",searchResults:"搜索结果",matches:"个匹配"},
ja:{name:"日本語",flag:"🇯🇵",code:"JA",live:"ライブ市場",coins:"コイン",updating:"市場データを更新中…",gainers:"上昇銘柄",losers:"下落銘柄",volume:"出来高",new:"新規上場",favorites:"お気に入り",featured:"注目",home10:"ホーム • 10コイン",hours:"時間",days:"日",market:"市場",watchlist:"ウォッチリスト",searchResults:"検索結果",matches:"件"},
de:{name:"Deutsch",flag:"🇩🇪",code:"DE",live:"Live-Markt",coins:"Coins",updating:"Marktdaten werden aktualisiert…",gainers:"Gewinner",losers:"Verlierer",volume:"Höchstes Volumen",new:"Neue Listings",favorites:"Favoriten",featured:"Highlights",home10:"Startseite • 10 Coins",hours:"Stunden",days:"Tage",market:"Markt",watchlist:"Beobachtungsliste",searchResults:"Suchergebnisse",matches:"Treffer"},
fr:{name:"Français",flag:"🇫🇷",code:"FR",live:"Marché en direct",coins:"cryptos",updating:"Mise à jour des données…",gainers:"Hausse",losers:"Baisse",volume:"Plus gros volumes",new:"Nouveaux listings",favorites:"Favoris",featured:"À la une",home10:"Accueil • 10 cryptos",hours:"heures",days:"jours",market:"marché",watchlist:"Votre liste",searchResults:"Résultats",matches:"correspondances"},
it:{name:"Italiano",flag:"🇮🇹",code:"IT",live:"Mercato live",coins:"coin",updating:"Aggiornamento dati…",gainers:"In rialzo",losers:"In ribasso",volume:"Volume più alto",new:"Nuove quotazioni",favorites:"Preferiti",featured:"In evidenza",home10:"Home • 10 coin",hours:"ore",days:"giorni",market:"mercato",watchlist:"La tua lista",searchResults:"Risultati",matches:"corrispondenze"},
ru:{name:"Русский",flag:"🇷🇺",code:"RU",live:"Рынок онлайн",coins:"монет",updating:"Обновление данных…",gainers:"Лидеры роста",losers:"Лидеры падения",volume:"Высокий объём",new:"Новые листинги",favorites:"Избранное",featured:"Избранные",home10:"Главная • 10 монет",hours:"часов",days:"дней",market:"рынок",watchlist:"Список наблюдения",searchResults:"Результаты поиска",matches:"совпадений"},
pt:{name:"Português",flag:"🇵🇹",code:"PT",live:"Mercado ao vivo",coins:"moedas",updating:"Atualizando dados…",gainers:"Altas",losers:"Baixas",volume:"Maior volume",new:"Novas listagens",favorites:"Favoritos",featured:"Destaques",home10:"Início • 10 moedas",hours:"horas",days:"dias",market:"mercado",watchlist:"Sua lista",searchResults:"Resultados",matches:"correspondências"},
ar:{name:"العربية",flag:"🇸🇦",code:"AR",live:"السوق المباشر",coins:"عملات",updating:"جارٍ تحديث بيانات السوق…",gainers:"الأعلى ارتفاعًا",losers:"الأعلى انخفاضًا",volume:"أعلى حجم",new:"إدراجات جديدة",favorites:"المفضلة",featured:"الأبرز",home10:"الرئيسية • 10 عملات",hours:"ساعات",days:"أيام",market:"السوق",watchlist:"قائمتي",searchResults:"نتائج البحث",matches:"نتائج"}
};
let currentLang=localStorage.getItem('hc_lang_v13')||'tr';
const t=k=>(LANGS[currentLang]&&LANGS[currentLang][k])||LANGS.tr[k]||k;
function buildLangMenu(){
 const m=$('#langMenu'); m.innerHTML=Object.entries(LANGS).map(([k,v])=>`<button class="${k===currentLang?'active':''}" data-lang="${k}">${v.flag} ${v.name}</button>`).join('');
 $('#langCurrent').textContent=LANGS[currentLang].code;
}
function applyLanguage(){
 document.documentElement.lang=currentLang;
 const tr=LANGS[currentLang];
 $('.eyebrow').textContent=tr.live;
 document.querySelector('.hero h1').textContent=currentLang==='tr'?'Kriptoyu keşfet.':currentLang==='en'?'Discover crypto.':currentLang==='es'?'Descubre las criptomonedas.':currentLang==='zh'?'探索加密货币。':currentLang==='ja'?'暗号資産を探す。':currentLang==='de'?'Krypto entdecken.':currentLang==='fr'?'Découvrez la crypto.':currentLang==='it'?'Scopri le crypto.':currentLang==='ru'?'Исследуйте криптовалюты.':currentLang==='pt'?'Explore cripto.':'استكشف العملات الرقمية.';
 const pmap={tr:'Binlerce USDT paritesi, sade ana ekran ve ayrıntılı coin ekranı.',en:'Thousands of USDT pairs, a clean home screen and detailed coin pages.',es:'Miles de pares USDT, una pantalla sencilla y detalles de cada moneda.',zh:'海量 USDT 交易对，简洁首页与详细币种页面。',ja:'多数のUSDTペア、シンプルなホームと詳細なコイン画面。',de:'Tausende USDT-Paare, eine klare Startseite und detaillierte Coin-Seiten.',fr:'Des milliers de paires USDT, une interface claire et des pages détaillées.',it:'Migliaia di coppie USDT, home semplice e dettagli delle monete.',ru:'Тысячи пар USDT, простой экран и подробные страницы монет.',pt:'Milhares de pares USDT, página inicial simples e detalhes das moedas.',ar:'آلاف أزواج USDT وواجهة بسيطة وصفحات تفصيلية للعملات.'};
 document.querySelector('.hero p').textContent=pmap[currentLang]||pmap.tr;
 $('#q').placeholder={tr:'BTC, ETH, SOL veya coin adı ara...',en:'Search BTC, ETH, SOL or coin...',es:'Busca BTC, ETH, SOL o una moneda...',zh:'搜索 BTC、ETH、SOL 或币种...',ja:'BTC、ETH、SOL またはコインを検索...',de:'BTC, ETH, SOL oder Coin suchen...',fr:'Rechercher BTC, ETH, SOL ou une crypto...',it:'Cerca BTC, ETH, SOL o una moneta...',ru:'Поиск BTC, ETH, SOL или монеты...',pt:'Pesquisar BTC, ETH, SOL ou moeda...',ar:'ابحث عن BTC أو ETH أو SOL أو عملة...'}[currentLang];
 const labels={home:{tr:'Genel',en:'Overview',es:'General',zh:'概览',ja:'概要',de:'Übersicht',fr:'Général',it:'Generale',ru:'Обзор',pt:'Geral',ar:'عام'},gainers:t('gainers'),losers:t('losers'),new:t('new'),volume:t('volume'),all:{tr:'Tüm Coinler',en:'All Coins',es:'Todas',zh:'全部币种',ja:'全コイン',de:'Alle Coins',fr:'Toutes les cryptos',it:'Tutti i coin',ru:'Все монеты',pt:'Todas',ar:'كل العملات'},fav:t('favorites')};
 $$('[data-v]').forEach(b=>{let k=b.dataset.v,val=labels[k];b.textContent=(k==='gainers'?'🚀 ':k==='losers'?'📉 ':k==='new'?'🆕 ':k==='volume'?'🔥 ':k==='fav'?'⭐ ':'')+(typeof val==='string'?val:val[currentLang]||val.tr)});
 $('#login').textContent={tr:'👤 Giriş',en:'👤 Sign in',es:'👤 Iniciar sesión',zh:'👤 登录',ja:'👤 ログイン',de:'👤 Anmelden',fr:'👤 Connexion',it:'👤 Accedi',ru:'👤 Войти',pt:'👤 Entrar',ar:'👤 دخول'}[currentLang];
 buildLangMenu();
}
function initLanguage(){
 buildLangMenu(); applyLanguage();
 $('#langBtn').onclick=e=>{e.stopPropagation();$('#langMenu').classList.toggle('hidden')};
 $('#langMenu').onclick=e=>{let b=e.target.closest('[data-lang]');if(!b)return;currentLang=b.dataset.lang;localStorage.setItem('hc_lang_v13',currentLang);applyLanguage();$('#langMenu').classList.add('hidden');render()};
 document.addEventListener('click',e=>{if(!e.target.closest('.lang-wrap'))$('#langMenu').classList.add('hidden')});
}
LANGS.tr.welcome='Hoş geldin'; LANGS.en.welcome='Welcome'; LANGS.es.welcome='Bienvenido'; LANGS.zh.welcome='欢迎'; LANGS.ja.welcome='ようこそ'; LANGS.de.welcome='Willkommen'; LANGS.fr.welcome='Bienvenue'; LANGS.it.welcome='Benvenuto'; LANGS.ru.welcome='Добро пожаловать'; LANGS.pt.welcome='Bem-vindo'; LANGS.ar.welcome='مرحبًا';
initLanguage();

$('#tabs').addEventListener('click',e=>{let b=e.target.closest('button[data-v]');if(!b)return;$$('#tabs button').forEach(x=>x.classList.remove('on'));b.classList.add('on');S.view=b.dataset.v;S.q='';$('#q').value='';render()});$('#q').addEventListener('input',e=>{S.q=e.target.value.trim();render()});document.body.addEventListener('click',e=>{let f=e.target.closest('[data-f]');if(f){e.stopPropagation();let s=f.dataset.f;S.fav.has(s)?S.fav.delete(s):S.fav.add(s);localStorage.setItem('hc_fav_v13',JSON.stringify([...S.fav]));render();return}let c=e.target.closest('[data-s]');if(c)openCoin(c.dataset.s)});$('#menuV17Final').onclick=()=>$('#menuV17FinalPanel').classList.add('open');$('#close').onclick=()=>{$('#modal').classList.add('hidden');$('#modal').setAttribute('aria-hidden','true');S.detailSymbol=null};$('#modal').addEventListener('click',e=>{if(e.target.id==='modal')$('#close').click()});$('#detail').addEventListener('click',e=>{let b=e.target.closest('[data-r]');if(b){S.range=b.dataset.r;$$('.range').forEach(x=>x.classList.remove('active'));b.classList.add('active');if(S.detailSymbol)loadChart(S.detailSymbol,S.range)}});load();setInterval(()=>{if(document.visibilityState==='visible')load()},60000);


// Lightweight local profile: no external authentication and no API calls.
(function(){
 const pm=$('#profileModal'), form=$('#loginForm'), logged=$('#profileLogged'), nameEl=$('#profileName'), emailEl=$('#profileEmail');
 const saved=()=>{try{return JSON.parse(localStorage.getItem('hc_profile_v13')||'null')}catch(e){return null}};
 function openProfile(){
   const p=saved();
   pm.classList.remove('hidden'); pm.setAttribute('aria-hidden','false');
   if(p){form.classList.add('hidden');logged.classList.remove('hidden');$('#welcomeText').textContent=(t('welcome')||'Hoş geldin')+', '+p.name+'!';}
   else{form.classList.remove('hidden');logged.classList.add('hidden');}
 }
 function closeProfile(){pm.classList.add('hidden');pm.setAttribute('aria-hidden','true')}
 $('#login').addEventListener('click',openProfile);
 $('#profileClose').addEventListener('click',closeProfile);
 pm.addEventListener('click',e=>{if(e.target===pm)closeProfile()});
 $('#saveProfile').addEventListener('click',()=>{
   const name=nameEl.value.trim(), email=emailEl.value.trim();
   if(!name){nameEl.focus();return}
   localStorage.setItem('hc_profile_v13',JSON.stringify({name,email}));
   openProfile();
 });
 $('#logoutProfile').addEventListener('click',()=>{localStorage.removeItem('hc_profile_v13');openProfile()});
})();


(function(){
 const F={
 tr:{intro:"Kripto piyasalarını sade, hızlı ve anlaşılır şekilde takip edin.",market:"Piyasa",tools:"Araçlar",infoTitle:"Hakkında",info:"Fiyat, değişim, hacim ve grafik verilerini tek bir ekranda inceleyin.",login:"Kullanıcı Girişi",disc:"Piyasa verileri otomatik olarak güncellenmektedir."},
 en:{intro:"Follow crypto markets in a clean, fast and easy-to-understand interface.",market:"Market",tools:"Tools",infoTitle:"About",info:"Review price, change, volume and chart data in one place.",login:"User Login",disc:"Market data is updated automatically."},
 es:{intro:"Sigue los mercados cripto de forma sencilla, rápida y clara.",market:"Mercado",tools:"Herramientas",infoTitle:"Acerca de",info:"Consulta precio, cambio, volumen y gráficos en un solo lugar.",login:"Acceso",disc:"Los datos de mercado se actualizan automáticamente."},
 zh:{intro:"以简洁、快速、清晰的方式关注加密市场。",market:"市场",tools:"工具",infoTitle:"关于",info:"在一个页面查看价格、涨跌、成交量和图表。",login:"用户登录",disc:"市场数据会自动更新。"},
 ja:{intro:"暗号資産市場をシンプルかつ高速に確認できます。",market:"市場",tools:"ツール",infoTitle:"概要",info:"価格、変動率、出来高、チャートを一か所で確認できます。",login:"ユーザーログイン",disc:"市場データは自動更新されます。"},
 de:{intro:"Verfolge Kryptomärkte einfach, schnell und übersichtlich.",market:"Markt",tools:"Tools",infoTitle:"Über uns",info:"Preis, Änderung, Volumen und Charts an einem Ort.",login:"Benutzer-Login",disc:"Marktdaten werden automatisch aktualisiert."},
 fr:{intro:"Suivez les marchés crypto de façon simple, rapide et claire.",market:"Marché",tools:"Outils",infoTitle:"À propos",info:"Consultez prix, variation, volume et graphiques au même endroit.",login:"Connexion",disc:"Les données de marché sont mises à jour automatiquement."},
 it:{intro:"Segui i mercati crypto in modo semplice, rapido e chiaro.",market:"Mercato",tools:"Strumenti",infoTitle:"Informazioni",info:"Prezzo, variazione, volume e grafici in un unico posto.",login:"Accesso",disc:"I dati di mercato vengono aggiornati automaticamente."},
 ru:{intro:"Следите за крипторынком просто, быстро и понятно.",market:"Рынок",tools:"Инструменты",infoTitle:"О платформе",info:"Цена, изменение, объём и графики в одном месте.",login:"Вход",disc:"Данные рынка обновляются автоматически."},
 pt:{intro:"Acompanhe o mercado cripto de forma simples, rápida e clara.",market:"Mercado",tools:"Ferramentas",infoTitle:"Sobre",info:"Veja preço, variação, volume e gráficos em um só lugar.",login:"Login",disc:"Os dados de mercado são atualizados automaticamente."},
 ar:{intro:"تابع أسواق العملات الرقمية بطريقة بسيطة وسريعة وواضحة.",market:"السوق",tools:"الأدوات",infoTitle:"حول المنصة",info:"راجع السعر والتغير والحجم والرسوم البيانية في مكان واحد.",login:"دخول المستخدم",disc:"يتم تحديث بيانات السوق تلقائيًا."}
 };
 function applyFooter(){
   const x=F[currentLang]||F.tr;
   $('#footerIntro').textContent=x.intro;$('#footerMarketTitle').textContent=x.market;$('#footerToolsTitle').textContent=x.tools;
   $('#footerInfoTitle').textContent=x.infoTitle;$('#footerInfo').textContent=x.info;$('#footerLogin').textContent=x.login;$('#footerDisclaimer').textContent=x.disc;
 }
 const oldApply=window.applyLanguage;
 // Existing applyLanguage is not global in all browsers; simply patch by wrapping render-triggered calls through a small observer.
 const observer=new MutationObserver(()=>applyFooter());
 observer.observe(document.body,{subtree:true,childList:true});
 applyFooter();
 document.querySelectorAll('[data-footer-v]').forEach(a=>a.addEventListener('click',e=>{
   e.preventDefault(); const v=a.dataset.footerV; const b=document.querySelector(`[data-v="${v}"]`); if(b)b.click(); window.scrollTo({top:0,behavior:'smooth'});
 }));
 $('#footerLogin').addEventListener('click',e=>{e.preventDefault();$('#login').click()});
})();


(function(){
 const panel=document.getElementById('menuV17FinalPanel');
 const close=document.getElementById('menuV17FinalClose');
 const modal=document.getElementById('finalToolModal');
 const mclose=document.getElementById('finalToolClose');
 const body=document.getElementById('finalToolBody');
 close.onclick=()=>panel.classList.remove('open');
 mclose.onclick=()=>modal.classList.add('hidden');
 modal.onclick=e=>{if(e.target===modal)modal.classList.add('hidden')};

 const content={
 info:'<h2>📘 Kripto Yatırımı Hakkında</h2><p>Kripto varlıkları incelerken fiyat, hacim, piyasa değeri, arz, likidite ve projenin kullanım alanı gibi verileri birlikte değerlendirebilirsin.</p><p>Bu bölüm eğitim amaçlıdır; yatırım tavsiyesi değildir.</p>',
 glossary:'<h2>📚 Kripto Sözlüğü</h2><ul><li><b>Market Cap:</b> Fiyat × dolaşımdaki arz.</li><li><b>Hacim:</b> Belirli süredeki işlem büyüklüğü.</li><li><b>Likidite:</b> Alım-satım kolaylığı.</li><li><b>Volatilite:</b> Fiyat hareketlerinin büyüklüğü.</li><li><b>DCA:</b> Düzenli aralıklarla yatırım.</li><li><b>ATH:</b> Tarihsel en yüksek fiyat.</li><li><b>ATL:</b> Tarihsel en düşük fiyat.</li></ul>',
 risk:'<h2>⚠️ Risk Bilgileri</h2><p>Kripto piyasasında fiyatlar hızlı değişebilir. Kaldıraçlı işlemler riski artırabilir. Özel anahtar ve kurtarma kelimeleri paylaşılmamalıdır.</p>',
 calc:'<h2>🧮 Yatırım Hesaplama</h2><label>Yatırım ($)<input id="fcA" type="number" value="1000"></label><label>Alış fiyatı ($)<input id="fcB" type="number" value="100"></label><label>Hedef fiyat ($)<input id="fcC" type="number" value="150"></label><button id="fcGo" type="button">Hesapla</button><p id="fcR"></p>',
 dca:'<h2>📅 DCA Hesaplama</h2><label>Aylık yatırım ($)<input id="fdA" type="number" value="100"></label><label>Ay sayısı<input id="fdM" type="number" value="12"></label><label>Yıllık varsayımsal getiri (%)<input id="fdR" type="number" value="10"></label><button id="fdGo" type="button">Hesapla</button><p id="fdRes"></p>'
 };
 document.querySelectorAll('[data-final-tool]').forEach(btn=>btn.onclick=()=>{
   body.innerHTML=content[btn.dataset.finalTool];
   panel.classList.remove('open'); modal.classList.remove('hidden');
   if(btn.dataset.finalTool==='calc')document.getElementById('fcGo').onclick=()=>{
     const a=+fcA.value,b=+fcB.value,c=+fcC.value,q=b?a/b:0,p=q*c-a;
     fcR.innerHTML=`Miktar: <b>${q.toFixed(8)}</b><br>Hedef değer: <b>$${(q*c).toLocaleString('en-US',{maximumFractionDigits:2})}</b><br>Kâr/Zarar: <b>${p>=0?'+':''}$${p.toLocaleString('en-US',{maximumFractionDigits:2})}</b>`;
   };
   if(btn.dataset.finalTool==='dca')document.getElementById('fdGo').onclick=()=>{
     const a=+fdA.value,m=+fdM.value,r=+fdR.value/100/12;let v=0;
     for(let i=0;i<m;i++)v=(v+a)*(1+r);
     fdRes.innerHTML=`Toplam yatırım: <b>$${(a*m).toLocaleString('en-US',{maximumFractionDigits:2})}</b><br>Model değeri: <b>$${v.toLocaleString('en-US',{maximumFractionDigits:2})}</b>`;
   };
 });
})();



/* V17 visible menu */
(function(){
  var button=document.getElementById('menuV17Final');
  var panel=document.getElementById('menuV17FinalPanel');
  var close=document.getElementById('menuV17FinalClose');
  if(!button||!panel||!close)return;

  button.onclick=function(e){
    e.preventDefault();
    e.stopPropagation();
    panel.classList.add('open');
    panel.setAttribute('aria-hidden','false');
  };
  close.onclick=function(e){
    e.preventDefault();
    e.stopPropagation();
    panel.classList.remove('open');
    panel.setAttribute('aria-hidden','true');
  };

  var calc=document.getElementById('mvCalc');
  if(calc) calc.onclick=function(){
    var amount=Number(document.getElementById('mvAmount').value)||0;
    var buy=Number(document.getElementById('mvBuy').value)||0;
    var target=Number(document.getElementById('mvTarget').value)||0;
    var qty=buy?amount/buy:0;
    var value=qty*target;
    var pnl=value-amount;
    document.getElementById('mvCalcResult').innerHTML=
      'Coin miktarı: <b>'+qty.toFixed(8)+'</b><br>'+
      'Hedef değer: <b>$'+value.toLocaleString('en-US',{maximumFractionDigits:2})+'</b><br>'+
      'Kâr/Zarar: <b>'+ (pnl>=0?'+':'') +'$'+pnl.toLocaleString('en-US',{maximumFractionDigits:2})+'</b>';
  };

  var dca=document.getElementById('mvDcaCalc');
  if(dca) dca.onclick=function(){
    var amount=Number(document.getElementById('mvDcaAmount').value)||0;
    var months=Number(document.getElementById('mvDcaMonths').value)||0;
    var rate=(Number(document.getElementById('mvDcaRate').value)||0)/100/12;
    var value=0;
    for(var i=0;i<months;i++) value=(value+amount)*(1+rate);
    var invested=amount*months;
    document.getElementById('mvDcaResult').innerHTML=
      'Toplam yatırım: <b>$'+invested.toLocaleString('en-US',{maximumFractionDigits:2})+'</b><br>'+
      'Model değeri: <b>$'+value.toLocaleString('en-US',{maximumFractionDigits:2})+'</b>';
  };
})();

/* Final V17 menu close fix */
(function(){
  function bindV17Close(){
    var panel=document.getElementById('menuV17FinalPanel');
    var close=document.getElementById('menuV17FinalClose');
    if(!panel||!close)return;
    close.type='button';
    close.onclick=function(e){
      if(e){e.preventDefault();e.stopImmediatePropagation();}
      panel.classList.remove('open');
      panel.setAttribute('aria-hidden','true');
      return false;
    };
    close.addEventListener('click',function(e){
      e.preventDefault();
      e.stopImmediatePropagation();
      panel.classList.remove('open');
      panel.setAttribute('aria-hidden','true');
    },true);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',bindV17Close);
  else bindV17Close();
})();

/* DEFINITIVE V17 CLOSE: document-level capture, works on touch/click */
(function(){
  function closeMenu(){
    var p=document.getElementById('menuV17FinalPanel');
    if(p){
      p.classList.remove('open');
      p.setAttribute('aria-hidden','true');
      p.style.right='';
    }
  }
  document.addEventListener('pointerup',function(e){
    var t=e.target;
    if(t && (t.id==='menuV17FinalClose' || (t.closest && t.closest('#menuV17FinalClose')))){
      e.preventDefault();
      e.stopPropagation();
      closeMenu();
    }
  },true);
  document.addEventListener('click',function(e){
    var t=e.target;
    if(t && (t.id==='menuV17FinalClose' || (t.closest && t.closest('#menuV17FinalClose')))){
      e.preventDefault();
      e.stopPropagation();
      closeMenu();
    }
  },true);
})();
